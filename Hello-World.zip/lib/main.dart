import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:intl/intl.dart' as intl;
import 'package:url_launcher/url_launcher.dart';

// ==========================================
// 📱 CONSTANTS & ADMIN SECRETS
// ==========================================
const String ADMIN_SECRET_PIN = "998877";
const String SECRET_SALT = "POS_FAST_SECURE_SALT_2026_PRO";
const String APP_VERSION = "1.0.0";

// ==========================================
// 📦 DATA MODELS
// ==========================================

class Product {
  final String id;
  final String name;
  final String barcode;
  final double sellingPrice;
  final double costPrice;
  final double stock;
  final String? category;
  final int createdAt;

  Product({
    required this.id,
    required this.name,
    required this.barcode,
    required this.sellingPrice,
    required this.costPrice,
    required this.stock,
    this.category,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'barcode': barcode,
        'sellingPrice': sellingPrice,
        'costPrice': costPrice,
        'stock': stock,
        'category': category,
        'createdAt': createdAt,
      };

  factory Product.fromMap(Map<String, dynamic> map) => Product(
        id: map['id'] ?? '',
        name: map['name'] ?? '',
        barcode: map['barcode'] ?? '',
        sellingPrice: (map['sellingPrice'] as num?)?.toDouble() ?? 0.0,
        costPrice: (map['costPrice'] as num?)?.toDouble() ?? 0.0,
        stock: (map['stock'] as num?)?.toDouble() ?? 0.0,
        category: map['category'],
        createdAt: (map['createdAt'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
      );
}

class CartItem {
  final Product product;
  int quantity;
  double unitPrice;
  double costPrice;

  CartItem({
    required this.product,
    this.quantity = 1,
    required this.unitPrice,
    required this.costPrice,
  });

  double get subtotal => quantity * unitPrice;
}

class InvoiceItem {
  final String productId;
  final String productName;
  final String barcode;
  final int quantity;
  final double unitPrice;
  final double costPrice;
  final double subtotal;

  InvoiceItem({
    required this.productId,
    required this.productName,
    required this.barcode,
    required this.quantity,
    required this.unitPrice,
    required this.costPrice,
    required this.subtotal,
  });

  Map<String, dynamic> toMap() => {
        'productId': productId,
        'productName': productName,
        'barcode': barcode,
        'quantity': quantity,
        'unitPrice': unitPrice,
        'costPrice': costPrice,
        'subtotal': subtotal,
      };

  factory InvoiceItem.fromMap(Map<String, dynamic> map) => InvoiceItem(
        productId: map['productId'] ?? '',
        productName: map['productName'] ?? '',
        barcode: map['barcode'] ?? '',
        quantity: (map['quantity'] as num?)?.toInt() ?? 1,
        unitPrice: (map['unitPrice'] as num?)?.toDouble() ?? 0.0,
        costPrice: (map['costPrice'] as num?)?.toDouble() ?? 0.0,
        subtotal: (map['subtotal'] as num?)?.toDouble() ?? 0.0,
      );
}

class Invoice {
  final String id;
  final String invoiceNumber;
  final int timestamp;
  final String type; // 'cash' | 'debt'
  final String? customerId;
  final String? customerName;
  final List<InvoiceItem> items;
  final double totalAmount;
  final double totalProfit;
  final double previousDebt;
  final double newDebtTotal;
  final double paidAmount;

  Invoice({
    required this.id,
    required this.invoiceNumber,
    required this.timestamp,
    required this.type,
    this.customerId,
    this.customerName,
    required this.items,
    required this.totalAmount,
    required this.totalProfit,
    this.previousDebt = 0.0,
    this.newDebtTotal = 0.0,
    this.paidAmount = 0.0,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'invoiceNumber': invoiceNumber,
        'timestamp': timestamp,
        'type': type,
        'customerId': customerId,
        'customerName': customerName,
        'items': items.map((e) => e.toMap()).toList(),
        'totalAmount': totalAmount,
        'totalProfit': totalProfit,
        'previousDebt': previousDebt,
        'newDebtTotal': newDebtTotal,
        'paidAmount': paidAmount,
      };

  factory Invoice.fromMap(Map<String, dynamic> map) => Invoice(
        id: map['id'] ?? '',
        invoiceNumber: map['invoiceNumber'] ?? '',
        timestamp: (map['timestamp'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
        type: map['type'] ?? 'cash',
        customerId: map['customerId'],
        customerName: map['customerName'],
        items: (map['items'] as List<dynamic>?)
                ?.map((e) => InvoiceItem.fromMap(e))
                .toList() ??
            [],
        totalAmount: (map['totalAmount'] as num?)?.toDouble() ?? 0.0,
        totalProfit: (map['totalProfit'] as num?)?.toDouble() ?? 0.0,
        previousDebt: (map['previousDebt'] as num?)?.toDouble() ?? 0.0,
        newDebtTotal: (map['newDebtTotal'] as num?)?.toDouble() ?? 0.0,
        paidAmount: (map['paidAmount'] as num?)?.toDouble() ?? 0.0,
      );
}

class Customer {
  final String id;
  final String name;
  final String phone;
  final double totalDebt;
  final int lastTransactionDate;
  final String? notes;

  Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.totalDebt,
    required this.lastTransactionDate,
    this.notes,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'phone': phone,
        'totalDebt': totalDebt,
        'lastTransactionDate': lastTransactionDate,
        'notes': notes,
      };

  factory Customer.fromMap(Map<String, dynamic> map) => Customer(
        id: map['id'] ?? '',
        name: map['name'] ?? '',
        phone: map['phone'] ?? '',
        totalDebt: (map['totalDebt'] as num?)?.toDouble() ?? 0.0,
        lastTransactionDate: (map['lastTransactionDate'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
        notes: map['notes'],
      );
}

class PaymentRecord {
  final String id;
  final String customerId;
  final String customerName;
  final double amount;
  final int timestamp;
  final double remainingDebtAfter;
  final String? notes;

  PaymentRecord({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.amount,
    required this.timestamp,
    required this.remainingDebtAfter,
    this.notes,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'customerId': customerId,
        'customerName': customerName,
        'amount': amount,
        'timestamp': timestamp,
        'remainingDebtAfter': remainingDebtAfter,
        'notes': notes,
      };

  factory PaymentRecord.fromMap(Map<String, dynamic> map) => PaymentRecord(
        id: map['id'] ?? '',
        customerId: map['customerId'] ?? '',
        customerName: map['customerName'] ?? '',
        amount: (map['amount'] as num?)?.toDouble() ?? 0.0,
        timestamp: (map['timestamp'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
        remainingDebtAfter:
            (map['remainingDebtAfter'] as num?)?.toDouble() ?? 0.0,
        notes: map['notes'],
      );
}

class StoreSettings {
  String storeName;
  String phone;
  String address;
  String currency;
  String footerMessage;
  bool soundEnabled;

  StoreSettings({
    this.storeName = 'بقالة وماركت الخير',
    this.phone = '0591234567',
    this.address = 'الشارع العام',
    this.currency = 'ر.س',
    this.footerMessage = 'شكراً لزيارتكم ونسعد بخدمتكم دائماً',
    this.soundEnabled = true,
  });

  Map<String, dynamic> toMap() => {
        'storeName': storeName,
        'phone': phone,
        'address': address,
        'currency': currency,
        'footerMessage': footerMessage,
        'soundEnabled': soundEnabled,
      };

  factory StoreSettings.fromMap(Map<String, dynamic> map) => StoreSettings(
        storeName: map['storeName'] ?? 'بقالة وماركت الخير',
        phone: map['phone'] ?? '0591234567',
        address: map['address'] ?? 'الشارع العام',
        currency: map['currency'] ?? 'ر.س',
        footerMessage: map['footerMessage'] ?? 'شكراً لزيارتكم',
        soundEnabled: map['soundEnabled'] ?? true,
      );
}

class SubscriptionInfo {
  String deviceId;
  int startDate;
  int endDate;
  bool isActive;
  int lastKnownTimestamp;
  bool isClockTampered;

  SubscriptionInfo({
    required this.deviceId,
    required this.startDate,
    required this.endDate,
    required this.isActive,
    required this.lastKnownTimestamp,
    this.isClockTampered = false,
  });

  Map<String, dynamic> toMap() => {
        'deviceId': deviceId,
        'startDate': startDate,
        'endDate': endDate,
        'isActive': isActive,
        'lastKnownTimestamp': lastKnownTimestamp,
        'isClockTampered': isClockTampered,
      };

  factory SubscriptionInfo.fromMap(Map<String, dynamic> map) =>
      SubscriptionInfo(
        deviceId: map['deviceId'] ?? 'POS-7A8F-3D21',
        startDate: (map['startDate'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
        endDate: (map['endDate'] as num?)?.toInt() ??
            DateTime.now().add(const Duration(days: 30)).millisecondsSinceEpoch,
        isActive: map['isActive'] ?? true,
        lastKnownTimestamp: (map['lastKnownTimestamp'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
        isClockTampered: map['isClockTampered'] ?? false,
      );
}

// ==========================================
// 🛡️ SECURITY & ACTIVATION UTILS
// ==========================================

String generateActivationKey(String deviceId, int months, String adminPin) {
  final cleanId = deviceId.trim().toUpperCase();
  final monthTag = months.toString().padLeft(2, '0');
  final raw = "$cleanId|$monthTag|$adminPin|$SECRET_SALT";

  int hash = 0;
  for (int i = 0; i < raw.length; i++) {
    hash = (hash * 31 + raw.codeUnitAt(i)) & 0xFFFFFFFF;
  }
  final hex = hash.toRadixString(16).toUpperCase().padLeft(8, '0');
  return "POS-M$monthTag-${hex.substring(0, 4)}-${hex.substring(4, 8)}";
}

bool validateActivationKey(String deviceId, String key,
    {Function(int months)? onSuccess}) {
  final cleanKey = key.trim().toUpperCase();
  final parts = cleanKey.split('-');
  if (parts.length != 4 || parts[0] != 'POS') return false;

  final monthStr = parts[1].replaceFirst('M', '');
  final months = int.tryParse(monthStr) ?? 1;

  final expected = generateActivationKey(deviceId, months, ADMIN_SECRET_PIN);
  if (cleanKey == expected) {
    if (onSuccess != null) onSuccess(months);
    return true;
  }
  return false;
}

// ==========================================
// 🗄️ STORAGE SERVICE (SQLite/SharedPreferences)
// ==========================================

class StorageService {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _seedDefaultData();
    verifySubscriptionClock();
  }

  static void _seedDefaultData() {
    if (!_prefs!.containsKey('pos_products')) {
      final defaultProducts = [
        Product(
            id: 'p1',
            name: 'حليب المراعي 1 لتر',
            barcode: '6281007001234',
            sellingPrice: 6.50,
            costPrice: 5.00,
            stock: 45,
            category: 'ألبان',
            createdAt: DateTime.now().millisecondsSinceEpoch),
        Product(
            id: 'p2',
            name: 'خبز صامولي كيس',
            barcode: '6281007005678',
            sellingPrice: 1.50,
            costPrice: 1.00,
            stock: 80,
            category: 'مخبوزات',
            createdAt: DateTime.now().millisecondsSinceEpoch),
        Product(
            id: 'p3',
            name: 'بيبسي علبة 330 مل',
            barcode: '012000000133',
            sellingPrice: 3.00,
            costPrice: 2.20,
            stock: 120,
            category: 'مشروبات',
            createdAt: DateTime.now().millisecondsSinceEpoch),
        Product(
            id: 'p4',
            name: 'أرز الشعلان 5 كجم',
            barcode: '6281007009999',
            sellingPrice: 42.00,
            costPrice: 35.00,
            stock: 25,
            category: 'أرز وحبوب',
            createdAt: DateTime.now().millisecondsSinceEpoch),
        Product(
            id: 'p5',
            name: 'زيت عافية 1.5 لتر',
            barcode: '6281007008888',
            sellingPrice: 19.50,
            costPrice: 16.00,
            stock: 30,
            category: 'زيوت',
            createdAt: DateTime.now().millisecondsSinceEpoch),
      ];
      saveProducts(defaultProducts);
    }

    if (!_prefs!.containsKey('pos_customers')) {
      final defaultCustomers = [
        Customer(
            id: 'c1',
            name: 'أبو فهد (الجار)',
            phone: '0501112233',
            totalDebt: 145.0,
            lastTransactionDate: DateTime.now().millisecondsSinceEpoch,
            notes: 'دفعات أسبوعية'),
        Customer(
            id: 'c2',
            name: 'سعد العتيبي',
            phone: '0554443322',
            totalDebt: 320.50,
            lastTransactionDate: DateTime.now().millisecondsSinceEpoch,
            notes: 'حساب شهري مع الراتب'),
        Customer(
            id: 'c3',
            name: 'أم عبدالله',
            phone: '0569998877',
            totalDebt: 75.0,
            lastTransactionDate: DateTime.now().millisecondsSinceEpoch),
      ];
      saveCustomers(defaultCustomers);
    }

    if (!_prefs!.containsKey('pos_subscription')) {
      final rand = Random();
      final devId =
          "POS-${rand.nextInt(9000) + 1000}-${rand.nextInt(9000) + 1000}";
      final now = DateTime.now().millisecondsSinceEpoch;
      final sub = SubscriptionInfo(
        deviceId: devId,
        startDate: now,
        endDate: now + (30 * 24 * 60 * 60 * 1000),
        isActive: true,
        lastKnownTimestamp: now,
      );
      saveSubscription(sub);
    }
  }

  static List<Product> getProducts() {
    final raw = _prefs?.getString('pos_products');
    if (raw == null) return [];
    final List list = jsonDecode(raw);
    return list.map((e) => Product.fromMap(e)).toList();
  }

  static Future<void> saveProducts(List<Product> products) async {
    final raw = jsonEncode(products.map((e) => e.toMap()).toList());
    await _prefs?.setString('pos_products', raw);
  }

  static Product? findProductByBarcode(String barcode) {
    final list = getProducts();
    try {
      return list.firstWhere((p) => p.barcode.trim() == barcode.trim());
    } catch (_) {
      return null;
    }
  }

  static Future<void> addOrUpdateProduct(Product product) async {
    final list = getProducts();
    final idx = list
        .indexWhere((p) => p.id == product.id || p.barcode == product.barcode);
    if (idx != -1) {
      list[idx] = product;
    } else {
      list.insert(0, product);
    }
    await saveProducts(list);
  }

  static Future<void> deleteProduct(String id) async {
    final list = getProducts();
    list.removeWhere((p) => p.id == id);
    await saveProducts(list);
  }

  static List<Invoice> getInvoices() {
    final raw = _prefs?.getString('pos_invoices');
    if (raw == null) return [];
    final List list = jsonDecode(raw);
    return list.map((e) => Invoice.fromMap(e)).toList();
  }

  static Future<void> saveInvoices(List<Invoice> invoices) async {
    final raw = jsonEncode(invoices.map((e) => e.toMap()).toList());
    await _prefs?.setString('pos_invoices', raw);
  }

  static Future<Invoice> createInvoice({
    required String type,
    required List<CartItem> items,
    String? customerId,
    String? customerName,
    double previousDebt = 0.0,
    double paidAmount = 0.0,
  }) async {
    final invNumber =
        "INV-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}";
    final totalAmount = items.fold(0.0, (sum, i) => sum + i.subtotal);
    final totalCost =
        items.fold(0.0, (sum, i) => sum + (i.quantity * i.costPrice));
    final totalProfit = totalAmount - totalCost;
    final newDebtTotal = previousDebt + totalAmount - paidAmount;

    final invoice = Invoice(
      id: "inv_${DateTime.now().millisecondsSinceEpoch}",
      invoiceNumber: invNumber,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      type: type,
      customerId: customerId,
      customerName: customerName,
      items: items
          .map((c) => InvoiceItem(
                productId: c.product.id,
                productName: c.product.name,
                barcode: c.product.barcode,
                quantity: c.quantity,
                unitPrice: c.unitPrice,
                costPrice: c.costPrice,
                subtotal: c.subtotal,
              ))
          .toList(),
      totalAmount: totalAmount,
      totalProfit: totalProfit,
      previousDebt: previousDebt,
      newDebtTotal: newDebtTotal,
      paidAmount: paidAmount,
    );

    final invoices = getInvoices();
    invoices.insert(0, invoice);
    await saveInvoices(invoices);

    final products = getProducts();
    for (var itm in items) {
      final pIdx = products.indexWhere((p) => p.id == itm.product.id);
      if (pIdx != -1) {
        final cur = products[pIdx];
        products[pIdx] = Product(
          id: cur.id,
          name: cur.name,
          barcode: cur.barcode,
          sellingPrice: cur.sellingPrice,
          costPrice: cur.costPrice,
          stock: max(0.0, cur.stock - itm.quantity),
          category: cur.category,
          createdAt: cur.createdAt,
        );
      }
    }
    await saveProducts(products);

    if (type == 'debt' && customerId != null) {
      final customers = getCustomers();
      final cIdx = customers.indexWhere((c) => c.id == customerId);
      if (cIdx != -1) {
        final c = customers[cIdx];
        customers[cIdx] = Customer(
          id: c.id,
          name: c.name,
          phone: c.phone,
          totalDebt: newDebtTotal,
          lastTransactionDate: DateTime.now().millisecondsSinceEpoch,
          notes: c.notes,
        );
        await saveCustomers(customers);
      }
    }

    return invoice;
  }

  static List<Customer> getCustomers() {
    final raw = _prefs?.getString('pos_customers');
    if (raw == null) return [];
    final List list = jsonDecode(raw);
    return list.map((e) => Customer.fromMap(e)).toList();
  }

  static Future<void> saveCustomers(List<Customer> customers) async {
    final raw = jsonEncode(customers.map((e) => e.toMap()).toList());
    await _prefs?.setString('pos_customers', raw);
  }

  static Future<Customer> addCustomer(
      String name, String phone, String? notes) async {
    final c = Customer(
      id: "c_${DateTime.now().millisecondsSinceEpoch}",
      name: name,
      phone: phone,
      totalDebt: 0.0,
      lastTransactionDate: DateTime.now().millisecondsSinceEpoch,
      notes: notes,
    );
    final list = getCustomers();
    list.insert(0, c);
    await saveCustomers(list);
    return c;
  }

  static List<PaymentRecord> getPayments() {
    final raw = _prefs?.getString('pos_payments');
    if (raw == null) return [];
    final List list = jsonDecode(raw);
    return list.map((e) => PaymentRecord.fromMap(e)).toList();
  }

  static Future<void> recordPayment(
      String customerId, double amount, String? notes) async {
    final customers = getCustomers();
    final cIdx = customers.indexWhere((c) => c.id == customerId);
    if (cIdx == -1) return;

    final customer = customers[cIdx];
    final remaining = max(0.0, customer.totalDebt - amount);

    customers[cIdx] = Customer(
      id: customer.id,
      name: customer.name,
      phone: customer.phone,
      totalDebt: remaining,
      lastTransactionDate: DateTime.now().millisecondsSinceEpoch,
      notes: customer.notes,
    );
    await saveCustomers(customers);

    final payment = PaymentRecord(
      id: "pay_${DateTime.now().millisecondsSinceEpoch}",
      customerId: customerId,
      customerName: customer.name,
      amount: amount,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      remainingDebtAfter: remaining,
      notes: notes,
    );

    final payments = getPayments();
    payments.insert(0, payment);
    await _prefs?.setString(
        'pos_payments', jsonEncode(payments.map((e) => e.toMap()).toList()));
  }

  static StoreSettings getSettings() {
    final raw = _prefs?.getString('pos_settings');
    if (raw == null) return StoreSettings();
    return StoreSettings.fromMap(jsonDecode(raw));
  }

  static Future<void> saveSettings(StoreSettings settings) async {
    await _prefs?.setString('pos_settings', jsonEncode(settings.toMap()));
  }

  static SubscriptionInfo getSubscription() {
    final raw = _prefs?.getString('pos_subscription');
    if (raw == null) {
      final now = DateTime.now().millisecondsSinceEpoch;
      return SubscriptionInfo(
        deviceId: 'POS-7A8F-3D21',
        startDate: now,
        endDate: now + (30 * 24 * 60 * 60 * 1000),
        isActive: true,
        lastKnownTimestamp: now,
      );
    }
    return SubscriptionInfo.fromMap(jsonDecode(raw));
  }

  static Future<void> saveSubscription(SubscriptionInfo sub) async {
    await _prefs?.setString('pos_subscription', jsonEncode(sub.toMap()));
  }

  static bool isSubscriptionActive() {
    final sub = getSubscription();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (sub.isClockTampered) return false;
    return sub.isActive && now <= sub.endDate;
  }

  static int getRemainingDays() {
    final sub = getSubscription();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now > sub.endDate) return 0;
    return ((sub.endDate - now) / (1000 * 60 * 60 * 24)).ceil();
  }

  static void verifySubscriptionClock() {
    final sub = getSubscription();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now < sub.lastKnownTimestamp - (60 * 60 * 1000)) {
      sub.isClockTampered = true;
      saveSubscription(sub);
    } else {
      sub.lastKnownTimestamp = now;
      saveSubscription(sub);
    }
  }

  static Future<bool> renewWithKey(String key) async {
    final sub = getSubscription();
    bool success = false;
    validateActivationKey(sub.deviceId, key, onSuccess: (months) {
      final now = DateTime.now().millisecondsSinceEpoch;
      final base = max(now, sub.endDate);
      sub.endDate = base + (months * 30 * 24 * 60 * 60 * 1000);
      sub.isActive = true;
      sub.isClockTampered = false;
      sub.lastKnownTimestamp = now;
      saveSubscription(sub);
      success = true;
    });
    return success;
  }

  static Future<void> simulateExpired() async {
    final sub = getSubscription();
    sub.endDate =
        DateTime.now().subtract(const Duration(days: 1)).millisecondsSinceEpoch;
    sub.isActive = false;
    await saveSubscription(sub);
  }

  static Future<void> simulateClockTamper() async {
    final sub = getSubscription();
    sub.isClockTampered = true;
    await saveSubscription(sub);
  }

  static Future<void> reset30Days() async {
    final sub = getSubscription();
    final now = DateTime.now().millisecondsSinceEpoch;
    sub.startDate = now;
    sub.endDate = now + (30 * 24 * 60 * 60 * 1000);
    sub.isActive = true;
    sub.isClockTampered = false;
    sub.lastKnownTimestamp = now;
    await saveSubscription(sub);
  }
}

// ==========================================
// 🚀 MAIN APPLICATION ENTRY POINT
// ==========================================

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  runApp(const PosQuickApp());
}

class PosQuickApp extends StatelessWidget {
  const PosQuickApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'نظام الكاشير والمحاسبة السريع',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        primaryColor: const Color(0xFF10B981),
        fontFamily: 'Cairo',
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          secondary: Color(0xFFF59E0B),
          surface: Color(0xFF171717),
          background: Color(0xFF0A0A0A),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child!,
        );
      },
      home: const MainRootScaffold(),
    );
  }
}

// ==========================================
// 🏛️ MAIN ROOT SCAFFOLD & GLOBAL LISTENER
// ==========================================

class MainRootScaffold extends StatefulWidget {
  const MainRootScaffold({Key? key}) : super(key: key);

  @override
  State<MainRootScaffold> createState() => _MainRootScaffoldState();
}

class _MainRootScaffoldState extends State<MainRootScaffold> {
  int _currentTabIndex = 0;
  final FocusNode _keyboardFocusNode = FocusNode();
  String _hardwareBuffer = '';
  int _lastHardwareKeyTime = 0;

  int _versionClickCount = 0;
  int _lastVersionClickTime = 0;

  @override
  void initState() {
    super.initState();
    _keyboardFocusNode.requestFocus();
  }

  void _handleHardwareKey(RawKeyEvent event) {
    if (event is RawKeyDownEvent) {
      final now = DateTime.now().millisecondsSinceEpoch;
      final timeDiff = now - _lastHardwareKeyTime;

      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.tab) {
        if (_hardwareBuffer.length >= 3) {
          final scannedBarcode = _hardwareBuffer.trim();
          _onHardwareBarcodeScanned(scannedBarcode);
        }
        _hardwareBuffer = '';
        _lastHardwareKeyTime = 0;
        return;
      }

      final char = event.character;
      if (char != null && char.isNotEmpty) {
        if (timeDiff > 120 && _hardwareBuffer.isNotEmpty) {
          _hardwareBuffer = '';
        }
        _hardwareBuffer += char;
        _lastHardwareKeyTime = now;
      }
    }
  }

  void _onHardwareBarcodeScanned(String barcode) {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CashSaleScreen(initialBarcode: barcode),
      ),
    );
  }

  void _onVersionTapped() {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastVersionClickTime < 2500) {
      _versionClickCount++;
      _lastVersionClickTime = now;
      if (_versionClickCount >= 12) {
        _versionClickCount = 0;
        HapticFeedback.heavyImpact();
        showDialog(
          context: context,
          builder: (_) => const AdminPanelDialog(),
        ).then((_) => setState(() {}));
      } else {
        setState(() {});
      }
    } else {
      _versionClickCount = 1;
      _lastVersionClickTime = now;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!StorageService.isSubscriptionActive()) {
      return SubscriptionLockScreen(onUnlocked: () => setState(() {}));
    }

    final pages = [
      HomeScreen(onOpenCash: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const CashSaleScreen()))
            .then((_) => setState(() {}));
      }, onOpenDebt: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const DebtSaleScreen()))
            .then((_) => setState(() {}));
      }),
      const ProductsScreen(),
      const DebtLedgerScreen(),
      const ReportsScreen(),
      const SettingsScreen(),
    ];

    return RawKeyboardListener(
      focusNode: _keyboardFocusNode,
      autofocus: true,
      onKey: _handleHardwareKey,
      child: Scaffold(
        drawer: const AppNavigationDrawer(),
        body: pages[_currentTabIndex],
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: Color(0xFF262626), width: 1)),
          ),
          child: NavigationBar(
            backgroundColor: const Color(0xFF141414),
            indicatorColor: const Color(0xFF10B981).withOpacity(0.2),
            selectedIndex: _currentTabIndex,
            onDestinationSelected: (i) => setState(() => _currentTabIndex = i),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.store_mall_directory_outlined),
                selectedIcon: Icon(Icons.store, color: Color(0xFF10B981)),
                label: 'الرئيسية',
              ),
              NavigationDestination(
                icon: Icon(Icons.inventory_2_outlined),
                selectedIcon: Icon(Icons.inventory_2, color: Color(0xFF10B981)),
                label: 'المنتجات',
              ),
              NavigationDestination(
                icon: Icon(Icons.people_outline),
                selectedIcon: Icon(Icons.people, color: Color(0xFFF59E0B)),
                label: 'دفتر الديون',
              ),
              NavigationDestination(
                icon: Icon(Icons.bar_chart_outlined),
                selectedIcon: Icon(Icons.bar_chart, color: Color(0xFF3B82F6)),
                label: 'التقارير',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings, color: Colors.white),
                label: 'الإعدادات',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 🏠 HOME DASHBOARD SCREEN
// ==========================================

class HomeScreen extends StatefulWidget {
  final VoidCallback onOpenCash;
  final VoidCallback onOpenDebt;

  const HomeScreen(
      {Key? key, required this.onOpenCash, required this.onOpenDebt})
      : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final invoices = StorageService.getInvoices();
    final customers = StorageService.getCustomers();
    final remainingDays = StorageService.getRemainingDays();

    final todayStart = DateTime.now();
    final startTimestamp =
        DateTime(todayStart.year, todayStart.month, todayStart.day)
            .millisecondsSinceEpoch;
    final todayInvoices =
        invoices.where((i) => i.timestamp >= startTimestamp).toList();
    final todaySales = todayInvoices.fold(0.0, (sum, i) => sum + i.totalAmount);
    final todayProfit =
        todayInvoices.fold(0.0, (sum, i) => sum + i.totalProfit);
    final totalMarketDebt = customers.fold(0.0, (sum, c) => sum + c.totalDebt);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.store, color: Color(0xFF10B981), size: 18),
                const SizedBox(width: 6),
                Text(settings.storeName,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w900)),
              ],
            ),
            const Text('نظام الكاشير السريع (أوفلاين 100%)',
                style: TextStyle(fontSize: 10, color: Color(0xFF10B981))),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: remainingDays <= 5
                  ? Colors.amber.withOpacity(0.2)
                  : const Color(0xFF10B981).withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: remainingDays <= 5
                      ? Colors.amber
                      : const Color(0xFF10B981)),
            ),
            child: Row(
              children: [
                Icon(Icons.shield,
                    size: 14,
                    color: remainingDays <= 5
                        ? Colors.amber
                        : const Color(0xFF10B981)),
                const SizedBox(width: 4),
                Text('$remainingDays يوم',
                    style: const TextStyle(
                        fontSize: 11, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                    child: _buildMetricCard(
                        'مبيعات اليوم',
                        '${todaySales.toStringAsFixed(1)} ${settings.currency}',
                        const Color(0xFF10B981))),
                const SizedBox(width: 8),
                Expanded(
                    child: _buildMetricCard(
                        'صافي الربح',
                        '+${todayProfit.toStringAsFixed(1)} ${settings.currency}',
                        const Color(0xFF14B8A6))),
                const SizedBox(width: 8),
                Expanded(
                    child: _buildMetricCard(
                        'ديون بالسوق',
                        '${totalMarketDebt.toStringAsFixed(1)} ${settings.currency}',
                        const Color(0xFFF59E0B))),
              ],
            ),
            const SizedBox(height: 20),

            // 🔥 BUTTON 1: [ 🛒 بيع كاش ]
            GestureDetector(
              onTap: widget.onOpenCash,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF059669),
                      Color(0xFF10B981),
                      Color(0xFF0D9488)
                    ],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFF10B981).withOpacity(0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 6)),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text('✨ مسح باركود فوري بالكاميرا',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 8),
                          const Text('🛒 بيع كاش',
                              style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white)),
                          const SizedBox(height: 4),
                          const Text(
                              'فتح الكاميرا والماسح، مسح متتالي، وحفظ نقدي',
                              style: TextStyle(
                                  fontSize: 11, color: Colors.white70)),
                        ],
                      ),
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(Icons.shopping_cart,
                          color: Colors.white, size: 32),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // 🔥 BUTTON 2: [ 📝 بيع دين / آجل ]
            GestureDetector(
              onTap: widget.onOpenDebt,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFFD97706),
                      Color(0xFFF59E0B),
                      Color(0xFFEA580C)
                    ],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFFF59E0B).withOpacity(0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 6)),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text('👤 اختيار الزبون أو إضافة جديد',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 8),
                          const Text('📝 بيع دين / آجل',
                              style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFF0A0A0A))),
                          const SizedBox(height: 4),
                          const Text(
                              'إضافة على الحساب، ترحيل الرصيد، وطباعة الفاتورة',
                              style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(Icons.receipt_long,
                          color: Color(0xFF0A0A0A), size: 32),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('حركات وفواتير اليوم',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white70)),
                Text('${todayInvoices.length} فواتير',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 10),

            todayInvoices.isEmpty
                ? Container(
                    padding: const EdgeInsets.all(30),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFF171717),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF262626)),
                    ),
                    child: const Text(
                        'لا توجد عمليات بيع اليوم بعد.\nامسح أول منتج عبر زر بيع كاش بالأعلى.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: min(todayInvoices.length, 10),
                    itemBuilder: (context, idx) {
                      final inv = todayInvoices[idx];
                      final isCash = inv.type == 'cash';
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF171717),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF262626)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: isCash
                                    ? const Color(0xFF10B981).withOpacity(0.1)
                                    : const Color(0xFFF59E0B).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                  isCash ? Icons.shopping_cart : Icons.person,
                                  color: isCash
                                      ? const Color(0xFF10B981)
                                      : const Color(0xFFF59E0B),
                                  size: 20),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                      isCash
                                          ? 'فاتورة كاش نقدي'
                                          : 'آجل: ${inv.customerName ?? 'زبون'}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13)),
                                  Text(
                                      '${inv.items.length} أصناف • ${intl.DateFormat('hh:mm a').format(DateTime.fromMillisecondsSinceEpoch(inv.timestamp))}',
                                      style: const TextStyle(
                                          fontSize: 10, color: Colors.grey)),
                                ],
                              ),
                            ),
                            Text(
                                '${inv.totalAmount.toStringAsFixed(2)} ${settings.currency}',
                                style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: isCash
                                        ? const Color(0xFF10B981)
                                        : const Color(0xFFF59E0B))),
                          ],
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricCard(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF171717),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF262626)),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          const SizedBox(height: 4),
          FittedBox(
              child: Text(value,
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: color))),
        ],
      ),
    );
  }
}

// ==========================================
// 🛒 CASH SALE SCREEN (High-Performance Camera)
// ==========================================

class CashSaleScreen extends StatefulWidget {
  final String? initialBarcode;
  const CashSaleScreen({Key? key, this.initialBarcode}) : super(key: key);

  @override
  State<CashSaleScreen> createState() => _CashSaleScreenState();
}

class _CashSaleScreenState extends State<CashSaleScreen> {
  final List<CartItem> _cart = [];
  final MobileScannerController _scannerController = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
    facing: CameraFacing.back,
    torchEnabled: false,
  );

  String? _lastScannedCode;
  int _lastScannedTimestamp = 0;
  bool _isTorchOn = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialBarcode != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _onBarcodeDetected(widget.initialBarcode!);
      });
    }
  }

  @override
  void dispose() {
    _scannerController.dispose();
    super.dispose();
  }

  void _onBarcodeDetected(String rawCode) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final clean = rawCode.trim();
    if (clean.isEmpty) return;

    if (clean == _lastScannedCode && now - _lastScannedTimestamp < 1500) {
      return;
    }
    if (now - _lastScannedTimestamp < 350) return;

    _lastScannedCode = clean;
    _lastScannedTimestamp = now;

    HapticFeedback.mediumImpact();
    SystemSound.play(SystemSoundType.click);

    final product = StorageService.findProductByBarcode(clean);
    if (product == null) {
      _showMissingProductDialog(clean);
      return;
    }

    setState(() {
      final existingIdx = _cart.indexWhere((c) => c.product.id == product.id);
      if (existingIdx != -1) {
        _cart[existingIdx].quantity += 1;
      } else {
        _cart.insert(
            0,
            CartItem(
                product: product,
                unitPrice: product.sellingPrice,
                costPrice: product.costPrice));
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('✅ تمت إضافة: ${product.name}'),
        duration: const Duration(milliseconds: 1200),
        backgroundColor: const Color(0xFF10B981),
      ),
    );
  }

  void _showMissingProductDialog(String barcode) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF171717),
        title: const Text('⚠️ باركود غير مسجل'),
        content: Text(
            'الباركود ($barcode) غير موجود في قائمة المنتجات. هل ترغب بإضافته الآن؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء', style: TextStyle(color: Colors.grey))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981)),
            onPressed: () {
              Navigator.pop(context);
              _openAddProductModal(initialBarcode: barcode);
            },
            child: const Text('إضافة المنتج',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _openAddProductModal({String? initialBarcode}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171717),
      builder: (_) => AddProductSheet(
        initialBarcode: initialBarcode,
        onSaved: (newProduct) {
          _onBarcodeDetected(newProduct.barcode);
        },
      ),
    );
  }

  void _openManualSearch() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171717),
      builder: (_) => ManualSearchSheet(onSelect: (product) {
        _onBarcodeDetected(product.barcode);
      }),
    );
  }

  void _checkoutCash() async {
    if (_cart.isEmpty) return;
    final invoice =
        await StorageService.createInvoice(type: 'cash', items: _cart);
    HapticFeedback.heavyImpact();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ReceiptDialog(
          invoice: invoice, onClose: () => Navigator.of(context).pop()),
    ).then((_) {
      Navigator.of(context).pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final totalAmount = _cart.fold(0.0, (sum, i) => sum + i.subtotal);
    final totalItems = _cart.fold(0, (sum, i) => sum + i.quantity);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('🛒 بيع كاش (نقدي)',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          if (_cart.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep, color: Colors.redAccent),
              onPressed: () => setState(() => _cart.clear()),
            ),
        ],
      ),
      body: Column(
        children: [
          // Top Barcode Camera Viewport
          Container(
            height: 180,
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF262626)),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              children: [
                MobileScanner(
                  controller: _scannerController,
                  onDetect: (capture) {
                    final barcodes = capture.barcodes;
                    for (final b in barcodes) {
                      if (b.rawValue != null) {
                        _onBarcodeDetected(b.rawValue!);
                      }
                    }
                  },
                ),
                // Optical Scan HUD Frame
                Center(
                  child: Container(
                    width: 240,
                    height: 100,
                    decoration: BoxDecoration(
                      border:
                          Border.all(color: const Color(0xFF10B981), width: 2),
                      borderRadius: BorderRadius.circular(16),
                      color: const Color(0xFF10B981).withOpacity(0.05),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 8,
                  left: 12,
                  right: 12,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(20)),
                      child: const Text(
                          'وجّه الكاميرا نحو الباركود للمسح السريع',
                          style:
                              TextStyle(fontSize: 11, color: Colors.white70)),
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: IconButton(
                    icon: Icon(_isTorchOn ? Icons.flash_on : Icons.flash_off,
                        color: _isTorchOn ? Colors.amber : Colors.white),
                    onPressed: () {
                      _scannerController.toggleTorch();
                      setState(() => _isTorchOn = !_isTorchOn);
                    },
                  ),
                ),
              ],
            ),
          ),

          // Search & Manual Add Action Buttons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF59E0B),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: _openManualSearch,
                    icon: const Icon(Icons.keyboard, size: 18),
                    label: const Text('🔢 إدخال يدوي / بحث',
                        style: TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 12)),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF171717),
                    foregroundColor: const Color(0xFF10B981),
                    side: const BorderSide(color: Color(0xFF262626)),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 16),
                  ),
                  onPressed: () => _openAddProductModal(),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('صنف جديد',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // Cart List Title
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('سلة المشتريات ($totalItems قطعة)',
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey)),
                Text(
                    'الإجمالي: ${totalAmount.toStringAsFixed(2)} ${settings.currency}',
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF10B981))),
              ],
            ),
          ),
          const SizedBox(height: 6),

          // Cart Items List
          Expanded(
            child: _cart.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.shopping_cart_outlined,
                            size: 48, color: Colors.grey),
                        SizedBox(height: 8),
                        Text('السلة فارغة. امسح الباركود لإضافة الأصناف.',
                            style: TextStyle(color: Colors.grey, fontSize: 12)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: _cart.length,
                    itemBuilder: (context, idx) {
                      final item = _cart[idx];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF171717),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF262626)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.product.name,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13)),
                                  Text(
                                      '${item.unitPrice} × ${item.quantity} = ${item.subtotal.toStringAsFixed(2)} ${settings.currency}',
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: Color(0xFF10B981))),
                                ],
                              ),
                            ),
                            // Stepper
                            Row(
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.remove_circle_outline,
                                      color: Colors.grey, size: 20),
                                  onPressed: () {
                                    setState(() {
                                      if (item.quantity > 1) {
                                        item.quantity--;
                                      } else {
                                        _cart.removeAt(idx);
                                      }
                                    });
                                  },
                                ),
                                Text('${item.quantity}',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14)),
                                IconButton(
                                  icon: const Icon(Icons.add_circle_outline,
                                      color: Color(0xFF10B981), size: 20),
                                  onPressed: () {
                                    setState(() {
                                      item.quantity++;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          // Bottom Fixed Checkout Button
          if (_cart.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: const BoxDecoration(
                color: Color(0xFF141414),
                border: Border(top: BorderSide(color: Color(0xFF262626))),
              ),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('المبلغ المطلوب',
                          style: TextStyle(fontSize: 10, color: Colors.grey)),
                      Text(
                          '${totalAmount.toStringAsFixed(2)} ${settings.currency}',
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF10B981))),
                    ],
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF10B981),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: _checkoutCash,
                      child: const Text('✅ إتمام البيع كاش وطباعة',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 14)),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ==========================================
// 📝 DEBT SALE SCREEN
// ==========================================

class DebtSaleScreen extends StatefulWidget {
  const DebtSaleScreen({Key? key}) : super(key: key);

  @override
  State<DebtSaleScreen> createState() => _DebtSaleScreenState();
}

class _DebtSaleScreenState extends State<DebtSaleScreen> {
  Customer? _selectedCustomer;
  final List<CartItem> _cart = [];
  final TextEditingController _paidAmountController =
      TextEditingController(text: '0');

  void _onProductScanned(String barcode) {
    final product = StorageService.findProductByBarcode(barcode);
    if (product == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('⚠️ المنتج غير موجود')));
      return;
    }

    setState(() {
      final idx = _cart.indexWhere((c) => c.product.id == product.id);
      if (idx != -1) {
        _cart[idx].quantity++;
      } else {
        _cart.insert(
            0,
            CartItem(
                product: product,
                unitPrice: product.sellingPrice,
                costPrice: product.costPrice));
      }
    });
  }

  void _checkoutDebt() async {
    if (_selectedCustomer == null || _cart.isEmpty) return;

    final paid = double.tryParse(_paidAmountController.text) ?? 0.0;
    final invoice = await StorageService.createInvoice(
      type: 'debt',
      items: _cart,
      customerId: _selectedCustomer!.id,
      customerName: _selectedCustomer!.name,
      previousDebt: _selectedCustomer!.totalDebt,
      paidAmount: paid,
    );

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ReceiptDialog(
          invoice: invoice, onClose: () => Navigator.of(context).pop()),
    ).then((_) {
      Navigator.of(context).pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final customers = StorageService.getCustomers();
    final totalAmount = _cart.fold(0.0, (sum, i) => sum + i.subtotal);
    final paid = double.tryParse(_paidAmountController.text) ?? 0.0;
    final prevDebt = _selectedCustomer?.totalDebt ?? 0.0;
    final finalDebt = prevDebt + totalAmount - paid;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('📝 بيع دين / آجل',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Select Customer Dropdown
            const Text('الزبون / صاحب الحساب',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF171717),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF262626)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<Customer>(
                  isExpanded: true,
                  value: _selectedCustomer,
                  hint: const Text('اختر الزبون من القائمة...',
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                  dropdownColor: const Color(0xFF171717),
                  items: customers.map((c) {
                    return DropdownMenuItem<Customer>(
                      value: c,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(c.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 13)),
                          Text(
                              'دين سابق: ${c.totalDebt.toStringAsFixed(1)} ${settings.currency}',
                              style: const TextStyle(
                                  fontSize: 11, color: Color(0xFFF59E0B))),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (c) => setState(() => _selectedCustomer = c),
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Action: Add Item by manual search
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF59E0B),
                foregroundColor: Colors.black,
                minimumSize: const Size(double.infinity, 45),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: const Color(0xFF171717),
                  builder: (_) => ManualSearchSheet(
                      onSelect: (p) => _onProductScanned(p.barcode)),
                );
              },
              icon: const Icon(Icons.add_shopping_cart, size: 18),
              label: const Text('إضافة أصناف للفاتورة',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 14),

            // Cart Items
            if (_cart.isNotEmpty) ...[
              const Text('الأصناف المحددة:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _cart.length,
                itemBuilder: (context, idx) {
                  final item = _cart[idx];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: const Color(0xFF171717),
                        borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('${item.product.name} (×${item.quantity})',
                            style: const TextStyle(fontSize: 12)),
                        Text(
                            '${item.subtotal.toStringAsFixed(2)} ${settings.currency}',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 14),
            ],

            // Calculation Summary Card
            if (_selectedCustomer != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF171717),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: const Color(0xFFF59E0B).withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    _buildCalcRow('الدين السابق',
                        '${prevDebt.toStringAsFixed(2)} ${settings.currency}'),
                    _buildCalcRow('مشتريات اليوم',
                        '+ ${totalAmount.toStringAsFixed(2)} ${settings.currency}'),
                    const Divider(color: Color(0xFF262626)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('المدفوع نقداً الآن',
                            style: TextStyle(fontSize: 12)),
                        SizedBox(
                          width: 80,
                          child: TextField(
                            controller: _paidAmountController,
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Color(0xFF10B981),
                                fontWeight: FontWeight.bold),
                            decoration: const InputDecoration(
                                isDense: true, border: UnderlineInputBorder()),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                      ],
                    ),
                    const Divider(color: Color(0xFF262626)),
                    _buildCalcRow('الرصيد المتبقي النهائي',
                        '${finalDebt.toStringAsFixed(2)} ${settings.currency}',
                        isBold: true, color: const Color(0xFFF59E0B)),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            if (_selectedCustomer != null && _cart.isNotEmpty)
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF59E0B),
                  foregroundColor: Colors.black,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: _checkoutDebt,
                child: const Text('📝 حفظ الفاتورة وترحيل الدين',
                    style:
                        TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCalcRow(String label, String val,
      {bool isBold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                  fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(val,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: isBold ? FontWeight.w900 : FontWeight.bold,
                  color: color ?? Colors.white)),
        ],
      ),
    );
  }
}

// ==========================================
// 📦 PRODUCTS MANAGEMENT SCREEN
// ==========================================

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({Key? key}) : super(key: key);

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final allProducts = StorageService.getProducts();
    final filtered = allProducts
        .where((p) =>
            p.name.contains(_searchQuery) || p.barcode.contains(_searchQuery))
        .toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('📦 إدارة المنتجات والمخزن',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle,
                color: Color(0xFF10B981), size: 28),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: const Color(0xFF171717),
                builder: (_) =>
                    AddProductSheet(onSaved: (_) => setState(() {})),
              ).then((_) => setState(() {}));
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (q) => setState(() => _searchQuery = q),
              decoration: InputDecoration(
                hintText: 'بحث بالاسم أو الباركود...',
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF171717),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: filtered.length,
              itemBuilder: (context, idx) {
                final p = filtered[idx];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF171717),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF262626)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12)),
                        child: const Icon(Icons.inventory_2,
                            color: Color(0xFF10B981), size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(p.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 13)),
                            Text(
                                'باركود: ${p.barcode} • المخزون: ${p.stock.toInt()}',
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.grey)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                              '${p.sellingPrice.toStringAsFixed(2)} ${settings.currency}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFF10B981),
                                  fontSize: 13)),
                          Text('تكلفة: ${p.costPrice.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  fontSize: 10, color: Colors.grey)),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 👥 DEBT LEDGER SCREEN
// ==========================================

class DebtLedgerScreen extends StatefulWidget {
  const DebtLedgerScreen({Key? key}) : super(key: key);

  @override
  State<DebtLedgerScreen> createState() => _DebtLedgerScreenState();
}

class _DebtLedgerScreenState extends State<DebtLedgerScreen> {
  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final customers = StorageService.getCustomers();
    final totalMarketDebt = customers.fold(0.0, (sum, c) => sum + c.totalDebt);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('📒 دفتر الديون والزبائن',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add, color: Color(0xFFF59E0B)),
            onPressed: () {
              _showAddCustomerDialog();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF9A3412), Color(0xFFD97706)]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إجمالي الديون المعلقة بالسوق',
                    style: TextStyle(fontSize: 11, color: Colors.white70)),
                const SizedBox(height: 4),
                Text(
                    '${totalMarketDebt.toStringAsFixed(2)} ${settings.currency}',
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: Colors.white)),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: customers.length,
              itemBuilder: (context, idx) {
                final c = customers[idx];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF171717),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF262626)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            color: const Color(0xFFF59E0B).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12)),
                        child: const Icon(Icons.person,
                            color: Color(0xFFF59E0B), size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(c.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 13)),
                            Text('هاتف: ${c.phone}',
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.grey)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                              '${c.totalDebt.toStringAsFixed(2)} ${settings.currency}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFFF59E0B),
                                  fontSize: 13)),
                          TextButton(
                            style: TextButton.styleFrom(
                                visualDensity: VisualDensity.compact,
                                foregroundColor: const Color(0xFF10B981)),
                            onPressed: () => _showPaymentDialog(c),
                            child: const Text('تسجيل سداد',
                                style: TextStyle(
                                    fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showAddCustomerDialog() {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF171717),
        title: const Text('إضافة زبون جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'اسم الزبون')),
            TextField(
                controller: phoneCtrl,
                decoration: const InputDecoration(labelText: 'رقم الهاتف')),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF59E0B)),
            onPressed: () async {
              if (nameCtrl.text.isNotEmpty) {
                await StorageService.addCustomer(
                    nameCtrl.text, phoneCtrl.text, '');
                setState(() {});
                Navigator.pop(context);
              }
            },
            child: const Text('إضافة',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showPaymentDialog(Customer c) {
    final amountCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF171717),
        title: Text('سداد دفعة: ${c.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('الرصيد الحالي: ${c.totalDebt}'),
            const SizedBox(height: 8),
            TextField(
                controller: amountCtrl,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'المبلغ المسدد نقداً')),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981)),
            onPressed: () async {
              final amt = double.tryParse(amountCtrl.text) ?? 0.0;
              if (amt > 0) {
                await StorageService.recordPayment(c.id, amt, 'سداد يدوي');
                setState(() {});
                Navigator.pop(context);
              }
            },
            child: const Text('حفظ السداد',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 📊 REPORTS SCREEN
// ==========================================

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final invoices = StorageService.getInvoices();

    final totalRevenue = invoices.fold(0.0, (sum, i) => sum + i.totalAmount);
    final totalProfit = invoices.fold(0.0, (sum, i) => sum + i.totalProfit);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('📊 التقارير والأرباح',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF171717),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF262626)),
              ),
              child: Column(
                children: [
                  _buildStatRow(
                      'إجمالي المبيعات التاريخية',
                      '${totalRevenue.toStringAsFixed(2)} ${settings.currency}',
                      const Color(0xFF3B82F6)),
                  const Divider(color: Color(0xFF262626)),
                  _buildStatRow(
                      'إجمالي الأرباح الصافية',
                      '+ ${totalProfit.toStringAsFixed(2)} ${settings.currency}',
                      const Color(0xFF10B981)),
                  const Divider(color: Color(0xFF262626)),
                  _buildStatRow('عدد الفواتير الصادرة',
                      '${invoices.length} فاتورة', Colors.white),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          Text(value,
              style: TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w900, color: color)),
        ],
      ),
    );
  }
}

// ==========================================
// ⚙️ SETTINGS SCREEN (With 12-Clicks Trigger)
// ==========================================

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int _clicks = 0;
  int _lastClick = 0;

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();
    final sub = StorageService.getSubscription();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('⚙️ الإعدادات وحالة النظام',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            tileColor: const Color(0xFF171717),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text('اسم المتجر / البقالة'),
            subtitle: Text(settings.storeName),
            leading: const Icon(Icons.store, color: Color(0xFF10B981)),
          ),
          const SizedBox(height: 10),
          ListTile(
            tileColor: const Color(0xFF171717),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text('معرف الجهاز (Device ID)'),
            subtitle: Text(sub.deviceId,
                style: const TextStyle(fontFamily: 'monospace')),
            leading: const Icon(Icons.phone_android, color: Color(0xFF3B82F6)),
          ),
          const SizedBox(height: 10),
          ListTile(
            tileColor: const Color(0xFF171717),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text('حالة الاشتراك السحابي'),
            subtitle: Text(StorageService.isSubscriptionActive()
                ? 'مفعل (متبقي ${StorageService.getRemainingDays()} يوم)'
                : 'منتهي الصلاحية'),
            leading: const Icon(Icons.verified_user, color: Color(0xFF10B981)),
          ),
          const SizedBox(height: 40),

          // 🤫 12-CLICKS SECRET TRIGGER
          Center(
            child: GestureDetector(
              onTap: () {
                final now = DateTime.now().millisecondsSinceEpoch;
                if (now - _lastClick < 2500) {
                  _clicks++;
                  _lastClick = now;
                  if (_clicks >= 12) {
                    _clicks = 0;
                    HapticFeedback.heavyImpact();
                    showDialog(
                      context: context,
                      builder: (_) => const AdminPanelDialog(),
                    ).then((_) => setState(() {}));
                  }
                } else {
                  _clicks = 1;
                  _lastClick = now;
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                    color: const Color(0xFF171717),
                    borderRadius: BorderRadius.circular(20)),
                child: Text('الإصدار $APP_VERSION (أوفلاين 100%)',
                    style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 👑 ADMIN PANEL DIALOG (12-Clicks Triggered)
// ==========================================

class AdminPanelDialog extends StatefulWidget {
  const AdminPanelDialog({Key? key}) : super(key: key);

  @override
  State<AdminPanelDialog> createState() => _AdminPanelDialogState();
}

class _AdminPanelDialogState extends State<AdminPanelDialog> {
  final TextEditingController _pinController = TextEditingController();
  bool _isAuthenticated = false;
  final TextEditingController _targetDeviceController = TextEditingController();
  int _selectedMonths = 1;
  String? _generatedKey;

  @override
  Widget build(BuildContext context) {
    final sub = StorageService.getSubscription();

    return AlertDialog(
      backgroundColor: const Color(0xFF171717),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(
        children: const [
          Icon(Icons.admin_panel_settings, color: Colors.amber),
          SizedBox(width: 8),
          Text('لوحة تحكم الآدمن السرية', style: TextStyle(fontSize: 16)),
        ],
      ),
      content: !_isAuthenticated
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('أدخل رمز PIN السري للإدارة:',
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(height: 10),
                TextField(
                  controller: _pinController,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(), hintText: 'PIN'),
                ),
              ],
            )
          : SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('توليد كود التفعيل للزبائن:',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 6),
                  TextField(
                    controller: _targetDeviceController..text = sub.deviceId,
                    decoration: const InputDecoration(
                        labelText: 'معرف جهاز الزبون (Device ID)'),
                  ),
                  const SizedBox(height: 10),
                  DropdownButton<int>(
                    value: _selectedMonths,
                    isExpanded: true,
                    dropdownColor: const Color(0xFF171717),
                    items: const [
                      DropdownMenuItem(
                          value: 1, child: Text('شهر واحد (1 Month)')),
                      DropdownMenuItem(
                          value: 3, child: Text('3 أشهر (3 Months)')),
                      DropdownMenuItem(
                          value: 6, child: Text('6 أشهر (6 Months)')),
                      DropdownMenuItem(
                          value: 12, child: Text('سنة كاملة (1 Year)')),
                    ],
                    onChanged: (v) => setState(() => _selectedMonths = v ?? 1),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.black),
                    onPressed: () {
                      final key = generateActivationKey(
                          _targetDeviceController.text,
                          _selectedMonths,
                          ADMIN_SECRET_PIN);
                      setState(() => _generatedKey = key);
                    },
                    child: const Text('توليد كود التفعيل الآن'),
                  ),
                  if (_generatedKey != null) ...[
                    const SizedBox(height: 10),
                    SelectableText('الكود: $_generatedKey',
                        style: const TextStyle(
                            color: Color(0xFF10B981),
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace')),
                  ],
                ],
              ),
            ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق')),
        if (!_isAuthenticated)
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981)),
            onPressed: () {
              if (_pinController.text == ADMIN_SECRET_PIN) {
                setState(() => _isAuthenticated = true);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('رمز PIN خاطئ!')));
              }
            },
            child: const Text('دخول'),
          ),
      ],
    );
  }
}

// ==========================================
// 🔒 SUBSCRIPTION LOCK SCREEN
// ==========================================

class SubscriptionLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const SubscriptionLockScreen({Key? key, required this.onUnlocked})
      : super(key: key);

  @override
  State<SubscriptionLockScreen> createState() => _SubscriptionLockScreenState();
}

class _SubscriptionLockScreenState extends State<SubscriptionLockScreen> {
  final TextEditingController _keyController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final sub = StorageService.getSubscription();

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, size: 64, color: Colors.amber),
              const SizedBox(height: 16),
              const Text('انتهت فترة الاشتراك التجريبي',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text(
                  'يرجى تجديد الاشتراك السحابي لمواصلة استخدام نظام الكاشير.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 16),
              SelectableText('معرف جهازك: ${sub.deviceId}',
                  style: const TextStyle(
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF10B981))),
              const SizedBox(height: 20),
              TextField(
                controller: _keyController,
                textAlign: TextAlign.center,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'POS-M01-XXXX-XXXX'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  minimumSize: const Size(double.infinity, 45),
                ),
                onPressed: () async {
                  final ok =
                      await StorageService.renewWithKey(_keyController.text);
                  if (ok) {
                    widget.onUnlocked();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('كود التفعيل غير صحيح!')));
                  }
                },
                child: const Text('تفعيل النظام الآن',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 🧾 RECEIPT MODAL DIALOG
// ==========================================

class ReceiptDialog extends StatelessWidget {
  final Invoice invoice;
  final VoidCallback onClose;

  const ReceiptDialog({Key? key, required this.invoice, required this.onClose})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settings = StorageService.getSettings();

    return AlertDialog(
      backgroundColor: const Color(0xFF171717),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Center(
          child: Text(settings.storeName,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
                child: Text('فاتورة #${invoice.invoiceNumber}',
                    style: const TextStyle(fontSize: 11, color: Colors.grey))),
            const Divider(color: Color(0xFF262626)),
            ...invoice.items.map((i) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${i.productName} × ${i.quantity}',
                          style: const TextStyle(fontSize: 11)),
                      Text('${i.subtotal.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontSize: 11, fontWeight: FontWeight.bold)),
                    ],
                  ),
                )),
            const Divider(color: Color(0xFF262626)),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('الإجمالي',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text(
                    '${invoice.totalAmount.toStringAsFixed(2)} ${settings.currency}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, color: Color(0xFF10B981))),
              ],
            ),
          ],
        ),
      ),
      actions: [
        ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF10B981)),
          onPressed: onClose,
          child: const Text('تم'),
        ),
      ],
    );
  }
}

// ==========================================
// 🔍 MANUAL SEARCH & ADD SHEETS
// ==========================================

class ManualSearchSheet extends StatelessWidget {
  final Function(Product) onSelect;
  const ManualSearchSheet({Key? key, required this.onSelect}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final products = StorageService.getProducts();

    return Container(
      padding: const EdgeInsets.all(16),
      height: MediaQuery.of(context).size.height * 0.7,
      child: Column(
        children: [
          const Text('🔢 إدخال يدوي / بحث عن صنف',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, idx) {
                final p = products[idx];
                return ListTile(
                  title: Text(p.name),
                  subtitle: Text('باركود: ${p.barcode}'),
                  trailing: Text('${p.sellingPrice} ر.س',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF10B981))),
                  onTap: () {
                    onSelect(p);
                    Navigator.pop(context);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class AddProductSheet extends StatefulWidget {
  final String? initialBarcode;
  final Function(Product) onSaved;

  const AddProductSheet({Key? key, this.initialBarcode, required this.onSaved})
      : super(key: key);

  @override
  State<AddProductSheet> createState() => _AddProductSheetState();
}

class _AddProductSheetState extends State<AddProductSheet> {
  final _nameCtrl = TextEditingController();
  final _barcodeCtrl = TextEditingController();
  final _sellPriceCtrl = TextEditingController();
  final _costPriceCtrl = TextEditingController();
  final _stockCtrl = TextEditingController(text: '100');

  @override
  void initState() {
    super.initState();
    if (widget.initialBarcode != null) {
      _barcodeCtrl.text = widget.initialBarcode!;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('إضافة منتج جديد للمخزن',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'اسم المنتج')),
            TextField(
                controller: _barcodeCtrl,
                decoration: const InputDecoration(labelText: 'الباركود')),
            Row(
              children: [
                Expanded(
                    child: TextField(
                        controller: _sellPriceCtrl,
                        keyboardType: TextInputType.number,
                        decoration:
                            const InputDecoration(labelText: 'سعر البيع'))),
                const SizedBox(width: 8),
                Expanded(
                    child: TextField(
                        controller: _costPriceCtrl,
                        keyboardType: TextInputType.number,
                        decoration:
                            const InputDecoration(labelText: 'سعر التكلفة'))),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  minimumSize: const Size(double.infinity, 45)),
              onPressed: () async {
                final product = Product(
                  id: 'p_${DateTime.now().millisecondsSinceEpoch}',
                  name: _nameCtrl.text,
                  barcode: _barcodeCtrl.text.isEmpty
                      ? '${Random().nextInt(900000) + 100000}'
                      : _barcodeCtrl.text,
                  sellingPrice: double.tryParse(_sellPriceCtrl.text) ?? 0.0,
                  costPrice: double.tryParse(_costPriceCtrl.text) ?? 0.0,
                  stock: double.tryParse(_stockCtrl.text) ?? 0.0,
                  createdAt: DateTime.now().millisecondsSinceEpoch,
                );
                await StorageService.addOrUpdateProduct(product);
                widget.onSaved(product);
                Navigator.pop(context);
              },
              child: const Text('حفظ المنتج'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class AppNavigationDrawer extends StatelessWidget {
  const AppNavigationDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF141414),
      child: ListView(
        children: const [
          DrawerHeader(
              child: Center(
                  child: Text('نظام الكاشير ونقاط البيع السريع',
                      style: TextStyle(fontWeight: FontWeight.bold)))),
        ],
      ),
    );
  }
}
